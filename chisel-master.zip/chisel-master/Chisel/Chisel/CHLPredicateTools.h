// Copyright 2004-present Facebook. All Rights Reserved.

#import <Foundation/Foundation.h>

#if defined(__cplusplus)
extern "C" {
#endif

NSSet *CHLVariableKeyPaths(NSPredicate *predicate);

#if defined(__cplusplus)
}
#endif
